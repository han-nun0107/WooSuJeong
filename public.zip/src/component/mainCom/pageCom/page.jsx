import "./page.css";

function Page() {
  return (
    <div className="main_sub_con1 grid">
      <h1 className="main_sub_con1_h1 font_color">페이지</h1>
      <div id="main_sub_con1__sec1"></div>
      <div id="main_sub_con1__sec2"></div>
      <div id="main_sub_con1__sec3"></div>
    </div>
  );
}

export default Page;
