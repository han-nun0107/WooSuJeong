function HeaderConLogo() {
  return (
    <div className="header_con_logo font_color">
      <a href="./index.html" className="font_color header_con_logo-link">
        YouTube Portfolio
      </a>
    </div>
  );
}

export default HeaderConLogo;
