function FooterConSec2() {
  return (
    <div className="footer_con_sec1">
      <div className="font_color">
        <a href="#" className="footer_a font_color">
          개인정보 처리방침
        </a>
      </div>
      <div className="font_color">
        <a href="#" className="footer_a font_color">
          접근성 표시 정보
        </a>
      </div>
    </div>
  );
}

export default FooterConSec2;
