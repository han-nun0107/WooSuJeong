function FooterConHead() {
  return (
    <div className="footer_con_sec1">
      <p className="footer_con_sec1__p font_color">
        YouTube <br />
        Portfolio
      </p>
    </div>
  );
}

export default FooterConHead;
