function FooterConSec4() {
  return (
    <div className="footer_copy font_color">
      &copy; 2025 by Han_nun Portfolio
    </div>
  );
}

export default FooterConSec4;
