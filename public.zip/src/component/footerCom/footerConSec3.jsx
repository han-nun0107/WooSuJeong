function FooterConSec3() {
  return (
    <div className="font_color" id="footer_con_dontCopy">
      저작권
    </div>
  );
}

export default FooterConSec3;
